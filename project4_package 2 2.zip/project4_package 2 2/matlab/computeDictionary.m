clear all;
close all;
imgPath = '../data/';
filterBank = createFilterBank();
alpha = 500;
K = 100;
dictionary = getDictionary(imgPath, alpha, K, 'random');
save('dictionaryRandom.mat', 'filterBank', 'dictionary');


dictionary = getDictionary(imgPath, alpha, K, 'harris');
save('dictionaryHarris.mat', 'filterBank', 'dictionary');


