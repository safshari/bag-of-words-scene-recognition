function [filterResponses] = extractFilterResponses(I, filterBank)

[w,h,c] = size(I);
if c==1
    I_(:,:,1)=I;
    I_(:,:,2)=I;
    I_(:,:,3)=I;
else
    I_ = I;
end
    
R = double(I_(:,:,1));
G = double(I_(:,:,2));
B = double(I_(:,:,3));
[L,a,b] = RGB2Lab(R,G,B);

for i =1 : length(filterBank)
    L_f(:,:,i) = imfilter(L,filterBank{i});
    a_f(:,:,i) = imfilter(a,filterBank{i});
    b_f(:,:,i) = imfilter(b,filterBank{i});
end
filterResponses(:,:,1:length(filterBank)) = L_f;
filterResponses(:,:,length(filterBank)+1:2*length(filterBank)) = a_f;
filterResponses(:,:,2*length(filterBank)+1:3*length(filterBank)) = b_f;

end