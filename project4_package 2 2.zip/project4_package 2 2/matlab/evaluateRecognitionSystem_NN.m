clear all;

load('../data/traintest.mat');
load('visionHarris.mat');
n_test = length(test_imagenames);
n_train = length(train_imagenames);
K = 100;

harris_chi = zeros(n_train, 1); 
harris_euc = zeros(n_train, 1); 

T_harris_chi = 0;
T_harris_euc = 0;

harris_chi_confusion = zeros(8, 8);
harris_euc_confusion = zeros(8, 8);



for i=1:n_test
    disp(i);
    I = imread(strcat('../data/', test_imagenames{i}));
    wordMap = getVisualWords(I, filterBank, dictionary');
    hist1 = getImageFeatures(wordMap, K);
    for s=1:n_train
        hist2 = trainFeatures(s, :);
        harris_chi(s) = getImageDistance(hist1, hist2, 'chi2');
        harris_euc(s) = getImageDistance(hist1, hist2, 'euclidean');     
    end
    [~, minharris_chi] = min(harris_chi);
    [~, minharris_euc] = min(harris_euc);
    label_c = trainLabels(minharris_chi);
    label_e = trainLabels(minharris_euc);
    
    realL = test_labels(i);
    
    
    if (label_c == realL)
        T_harris_chi = T_harris_chi + 1;
    end
    
    if (label_e == realL)
        T_harris_euc = T_harris_euc + 1;
    end
    
      
    harris_euc_confusion(realL, label_e) = harris_euc_confusion(realL, label_e) + 1;
    harris_chi_confusion(realL, label_c) = harris_chi_confusion(realL, label_c) + 1;
end

rand_chi = zeros(n_train, 1); 
rand_euc = zeros(n_train, 1);

T_rand_chi = 0;
T_rand_euc = 0;

rand_euc_confusion = zeros(8, 8);
rand_chi_confusion = zeros(8, 8);

load('visionRandom.mat');

fprintf('Running NN for Random \n');
%find closest neighbor for each image
for i=1:n_test
    I = imread(strcat('../data/', test_imagenames{i}));
    vw = strcat(test_imagenames{i}(1:end-4), '.mat');
    load(strcat('../data/', vw));
    hist1 = getImageFeatures(wordMap, K);
    for s=1:n_train
        hist2 = trainFeatures(s, :);
        rand_chi(s) = getImageDistance(hist1, hist2, 'chi2');
        rand_euc(s) = getImageDistance(hist1, hist2, 'euclidean');     
    end
    [~, minrand_chi] = min(rand_chi);
    [~, minrand_euc] = min(rand_euc);
    label_c = trainLabels(minrand_chi);
    label_e = trainLabels(minrand_euc);
    
    realL = test_labels(i);
    
    %increment number correct
    if (label_c == realL)
        T_rand_chi = T_rand_chi + 1;
    end
    
    if (label_e == realL)
        T_rand_euc = T_rand_euc + 1;
    end
    
    %filling in confusion matrix   
    rand_chi_confusion(realL, label_c) = rand_chi_confusion(realL, label_c) + 1;
    rand_euc_confusion(realL, label_e) = rand_euc_confusion(realL, label_e) + 1;
end

fprintf('The accuracy of harris and chi-squared is %4.2f \n', T_harris_chi/n_test);
fprintf('The confusion matrix for harris and chi-squared is: \n');
disp(harris_chi_confusion);

fprintf('\n The accuracy of harris and euclidean is %4.2f \n', T_harris_euc/n_test);
fprintf('The confusion matrix for harris and euclidean is: \n');
disp(harris_euc_confusion);

fprintf('\n The accuracy of random and chi-squared is %4.2f \n', T_rand_chi/n_test);
fprintf('The confusion matrix for random and chi-squared is: \n');
disp(rand_chi_confusion);


fprintf('\n The accuracy of random and euclidean is %4.2f \n', T_rand_euc/n_test);
fprintf('The confusion matrix for random and euclidean is: \n');
disp(rand_euc_confusion);


