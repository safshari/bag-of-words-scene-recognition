function [points] = getRandomPoints(I, alpha)


    r_x = randi([1 size(I,1)],1,alpha);
    r_y = randi([1 size(I,2)],1,alpha);
    points(:,1) = r_x' ; 
    points(:,2) = r_y';

end

