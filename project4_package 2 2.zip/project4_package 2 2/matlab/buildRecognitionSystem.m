load('../data/traintest.mat', 'train_imagenames', 'train_labels');
trainLabels = train_labels';
T = length(train_imagenames);
K = 100;
trainFeatures = zeros(T, K);

try
    fprintf('Closing any pools...\n');
%     matlabpool close; 
    delete(gcp('nocreate'))
catch ME
    disp(ME.message);
end

fprintf('Starting a pool of workers with %d cores\n', 2);
% matlabpool('local',numCores);
parpool('local', 2);
load('dictionaryHarris.mat');
load('filterBank');
% filterBank = filterBank;
% dictionary = dictionary;
parfor i=1:T
    I = imread(strcat('../data/', train_imagenames{i}));
    wordMap = getVisualWords(I, filterBank, dictionary');
    %figure,imshow(I);
    %figure,imshow(label2rgb(wordMap));
    hist = getImageFeatures(wordMap, K);
    trainFeatures(i, :) = hist;
end
save('visionHarris.mat', 'dictionary', 'filterBank', 'trainFeatures','trainLabels');

fprintf('Loading Random \n');
load('dictionaryRandom.mat', 'filterBank', 'dictionary');
parfor i=1:T
    I = imread(strcat('../data/', train_imagenames{i}));
    wordMap = getVisualWords(I, filterBank, dictionary');
    hist = getImageFeatures(wordMap, K);
    trainFeatures(i, :) = hist;
end
save('visionRandom.mat', 'dictionary', 'filterBank', 'trainFeatures', 'trainLabels'); 
                          
fprintf('Finished \n');
                       