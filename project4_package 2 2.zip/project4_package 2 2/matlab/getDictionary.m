function [dictionary] = getDictionary(imgPaths, alpha, K, method)
    [filterBank] = createFilterBank();

    traintest = load([imgPaths,'traintest.mat']);
    T = length(traintest.train_imagenames);
    for i=1:T
         I = imread([imgPaths,traintest.train_imagenames{i}]);
         filterResponses = extractFilterResponses(I, filterBank);
         if strcmp(method,'random')
             points = getRandomPoints(I, alpha); %0.04-0.06
         end
         if strcmp(method,'harris')
             points = getHarrisPoints(I, alpha , 0.06); %0.04-0.06
         end
         for j = 1:alpha
            pixelResponses((i-1)*alpha+j,:) = squeeze(filterResponses(points(j,1),points(j,2),:));
         end


    end
    [~, dictionary] = kmeans(pixelResponses, K, 'EmptyAction', 'drop');


end