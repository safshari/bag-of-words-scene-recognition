function [wordMap] = getVisualWords(I, filterBank, dictionary)
    dictionary = dictionary';
    filterResponses = extractFilterResponses(I, filterBank);

    
    n = length(filterBank);

    filterResponses_v = reshape(filterResponses, [size(filterResponses,1)*size(filterResponses,2), size(filterResponses,3)]); 
   
    D = pdist2(filterResponses_v, dictionary, 'euclidean');

    [~,closestK] = min(D,[],2);
    rows = size(I, 1);
    cols = size(I, 2);
    wordMap = reshape(closestK, rows, cols);
end


