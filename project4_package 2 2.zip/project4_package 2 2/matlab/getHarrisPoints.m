function [points] = getHarrisPoints(I, alpha, k)
points = zeros(alpha, 2);

if size(I,3) > 1
    I = rgb2gray(I);
end
I = im2double(I);

g_x = fspecial('sobel');
g_y = g_x';

Ix = imfilter(I, g_x);
Iy = imfilter(I, g_y);

Ixx = Ix .* Ix;
Iyy = Iy .* Iy;
Ixy = Ixx .* Iyy;

window = ones(3,3);

as = imfilter(Ixx, window);
bs = imfilter(Ixy, window);
cs = imfilter(Ixy, window);
ds = imfilter(Iyy, window);

trace_sq = k*((as + ds).^2);
det = (as .* ds) - (cs .* bs);
Rs = det - trace_sq;
%figure, imshow(mat2gray(Rs),[]); 
[~,sortIndex] = sort(Rs(:),'descend');  
                                                
maxIndex = sortIndex(1:alpha);

[points(:, 1), points(:, 2)] = ind2sub(size(I), maxIndex);

 
% dx = [-1 0 1; -1 0 1; -1 0 1]; % image derivatives
% dy = dx';
% Ix = imfilter(I, dx);    % Step 1: Compute the image derivatives Ix and Iy
% Iy = imfilter(I, dy);
% g = fspecial('gaussian',9,2); % Step 2: Generate Gaussian filter 'g' of size 9x9 and standard deviation Sigma=2.
% Ix2 = imfilter(Ix.^2, g); % Step 3: Smooth the squared image derivatives to obtain Ix2, Iy2 and IxIy
% figure;imshow(Ix2);
% Iy2 = imfilter(Iy.^2, g);
% figure;imshow(Iy2);
% IxIy = imfilter(Ix.*Iy, g);
% figure;imshow(IxIy); %Display the images obtained in different steps
% %% part 1- Compute Matrix E which contains for every point the value
% [r c]=size(Ix2);
% E = zeros(r, c); % Compute matrix E
% tic
% for i=2:1:r-1 
%     for j=2:1:c-1
%      Ix21=sum(sum(Ix2(i-1:i+1,j-1:j+1)));
%      Iy21=sum(sum(Iy2(i-1:i+1,j-1:j+1)));
%      IxIy1= sum(sum(IxIy(i-1:i+1,j-1:j+1)));
%      M=[Ix21 IxIy1;IxIy1 Iy21]; %(1) Build autocorrelation matrix for every singe pixel considering a window of size 3x3
%      E(i,j)=min(eig(M)); %(2)Compute Eigen value of the autocorrelation matrix and save the minimum eigenvalue as the desired value.
%     end
% end
% t=toc;
% disp('time needed for calculating E matrix');
% disp(t);
% figure, imshow(mat2gray(E)); % display result
% %% part 2- Compute Matrix R which contains for every point the cornerness score.
% [r c]=size(Ix2);
% R = zeros(r, c);
% k = 0.04;
% tic
% for i=2:1:r-1
%     for j=2:1:c-1
%      Ix21=sum(sum(Ix2(i-1:i+1,j-1:j+1)));
%      Iy21=sum(sum(Iy2(i-1:i+1,j-1:j+1)));
%      IxIy1= sum(sum(IxIy(i-1:i+1,j-1:j+1)));
%      M=[Ix21 IxIy1;IxIy1 Iy21];
%      R(i,j)=det(M)-k*trace(M).^2; %(1) Build autocorrelation matrix for every singe pixel considering a window of size 3x3
%     end
% end
% t=toc;
% figure, imshow(mat2gray(R)); % display result
% disp('time for calculating R matrix');
% disp(t);
% %% Part 3 - Select for E and R the 81 most salient points
% % Get the coordinates with maximum cornerness responses
% % Write a function to obtain the 81 most salient points
% numPts = alpha;
% [sortR,RIX] = sort(R(:),'descend');
% [a, b] = ind2sub([r c],RIX);%The mapping from linear indexes to subscript equivalents for the matrix
% figure; imshow(I, []); hold on; xlabel('Max 81 points');% Get the coordinates with maximum cornerness responses     
% for i=1:numPts 
% 	plot(b(i), a(i), 'r+'); 
% end  
% %% Part 4 - Build  a  function  to  carry  out  non-maximal  suppression  for  E  and
% % R.  Again, the 81 most salient points using a non-maximal suppression of 11?11 pixels.
% R1= ordfilt2(R,121,ones(11));% Get the coordinates with maximum cornerness responses
% R2=(R1==R) & (R > 10);
% [sortR2,R2IX] = sort(R2(:),'descend');
% [a, b] = ind2sub([r c],R2IX); %The mapping from linear indexes to subscript equivalents for the matrix
% figure; imshow(I, []); hold on; xlabel('Max 81 points'); %labeling along with X axis    
% for i=1:numPts 
% 	plot(b(i), a(i), 'r+'); 
% end


end