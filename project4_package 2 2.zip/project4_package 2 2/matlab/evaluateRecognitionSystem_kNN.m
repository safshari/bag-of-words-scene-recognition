clear all;
load('../data/traintest.mat');
load('visionRandom.mat');
K = 100;

n_test = length(test_imagenames);
n_train = length(train_imagenames);

classes = zeros(n_test, 40);

T_variousK = zeros(40, 1);

rand_chi = zeros(n_train, 1);

confusion = zeros(8, 8);

for k = 1:40
    
    for i=1:n_test
        votes = zeros(8,1);
        
        I = imread(strcat('../data/', test_imagenames{i}));
        img_name = strcat(test_imagenames{i}(1:end-4), '.mat');
        load(strcat('../data/', img_name));
        hist1 = getImageFeatures(wordMap, K);
        for s=1:n_train
            hist2 = trainFeatures(s, :);
            rand_chi(s) = getImageDistance(hist1, hist2, 'chi2');   
        end
        
       
        [~, sortedI] = sort(rand_chi);
        knearest = sortedI(1:k);
        
       
        for n=1:k
            label = trainLabels(knearest(n));
            votes(label) = votes(label) + 1;
        end
        
       
        [~, class] = max(votes);
        
        classes(i, k) = class;
        
        realL = test_labels(i);
        if realL == class
            T_variousK(k) = T_variousK(k) + 1;
        end
        
    end
end

[~, bestk] = max(T_variousK);
accuracy = T_variousK ./ n_test;

for i=1:n_test 
    real = test_labels(i);   
    j = classes(i, bestk);
    confusion(real, j) = confusion(real, j) + 1;
end

fprintf('The confusion matrix for the best k is: \n');
disp(confusion);
plot(accuracy);
